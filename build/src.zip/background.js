chrome.app.runtime.onLaunched.addListener(function() {
    chrome.app.window.create('page.html', {
        id: 'main',
        bounds: { width: 767, height: 540 }
      });
});